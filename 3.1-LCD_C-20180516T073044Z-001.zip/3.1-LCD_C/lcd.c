#include <mega32.h>

// Alphanumeric LCD functions
#include <alcd.h>
#include <delay.h>
// Declare your global variables here

void main(void)
{
char text[20]="AVR Devp.Board";

// Alphanumeric LCD initialization
// Connections are specified in the
// Project|Configure|C Compiler|Libraries|Alphanumeric LCD menu:
// RS - PORTD Bit 4
// RD - PORTD Bit 5
// EN - PORTD Bit 6
// D4 - PORTC Bit 4
// D5 - PORTC Bit 5
// D6 - PORTC Bit 6
// D7 - PORTC Bit 7
// Characters/line: 16
lcd_init(16);

while (1)
      {
      // Place your code here
      lcd_clear();
      lcd_gotoxy(0,0);      
      lcd_puts(text);        
      //lcd_putsf("AVR Devp. Board");
      delay_ms(1000);
      lcd_gotoxy(0,1);
      lcd_putsf("LCD Test Program");
      delay_ms(2000);
      lcd_clear();
      lcd_gotoxy(0,0);
      lcd_putsf("ATmega 32");
      delay_ms(1000);
      lcd_gotoxy(0,1);
      lcd_putsf("Microcontroller");
      delay_ms(2000);
      }
}
