#include <mega32a.h>
#include <delay.h>

void main(void)
{
DDRC=0xFF;
PORTC=0xFF;

while (1)
      {
      PORTC=~PORTC;
      delay_ms(1000);
      }
}
