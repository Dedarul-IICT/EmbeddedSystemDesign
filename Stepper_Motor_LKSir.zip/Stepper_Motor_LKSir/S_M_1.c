#include <mega32.h>
#include <delay.h>
#define OutPort PORTA
int d_value=100;

void half_step(void)
{
        OutPort=0b00000011;
        delay_ms(d_value);
        OutPort=0b00000010;
        delay_ms(d_value);

        OutPort=0b00000110;
        delay_ms(d_value);
        OutPort=0b00000100;
        delay_ms(d_value);

        OutPort=0b00001100;
        delay_ms(d_value);
        OutPort=0b00001000;
        delay_ms(d_value);                   

        OutPort=0b00001001;
        delay_ms(d_value);  
        OutPort=0b00000001;
        delay_ms(d_value);
}

void full_step_anticlockwise(void)
{
        OutPort=0b00000110;
        delay_ms(100);
        OutPort=0b00001100;
        delay_ms(100);
        OutPort=0b00001001;
        delay_ms(100);
        OutPort=0b00000011;
        delay_ms(100);
}

void full_step_clockwise(void)
{
        OutPort=0b00000110;
        delay_ms(d_value);
        OutPort=0b00000011;
        delay_ms(d_value);
        OutPort=0b00001001;
        delay_ms(d_value);
        OutPort=0b00001100;
        delay_ms(d_value);
}

void main(void)
{
DDRA=0xFF;

while (1)
      {   
      full_step_clockwise();
      }                                    
}
