/*****************************************************
Chip type           : ATmega32L
Program type        : Application
Clock frequency     : 8.000000 MHz
Memory model        : Small
External SRAM size  : 0
Data Stack size     : 512
*****************************************************/

#include <mega32.h>
#include <delay.h>

  char fs[4]={8,4,2,1};
  char hs[8]={1,2,4,8};
void main(void)
{
 char i=0;
 char j=0;
 char s=0;

PORTA=0x00;
DDRA=0x00;
 
PORTB=0xFF;
DDRB=0x00;

PORTC=0x00;
DDRC=0x0F;
 
PORTD=0x00;
DDRD=0x00;

ACSR=0x80;
SFIOR=0x00;

while (1)
    { 
        if(PINB.0==0){
            do{
                for (j=0;j<=16;j++) {
                    if(PINB.1==0){s=1;}
                    PORTC=fs[i];
                    i++;
                    delay_ms(100);
                    if(i==4){i=0;}
                };
                
                for (j=0;j<=16;j++) {
                    if(PINB.1==0){s=1;}
                    i--;
                    if(i==255){i=3;}
                    PORTC=fs[i];
                    delay_ms(100); 
                };
                 
            }while(s==0);
            s=0;    
        }
    }
}